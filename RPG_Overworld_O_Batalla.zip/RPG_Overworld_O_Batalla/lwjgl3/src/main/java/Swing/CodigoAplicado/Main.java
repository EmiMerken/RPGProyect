package Swing.CodigoAplicado;

import Swing.Fight.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.Collection;

public class Main {

    public static FBattle battle;
    public static FPlayer player;
    public static FTextBox textBox;
    public static FCommand command;
    public static FEnemy enemy;

    public static void main(String[] args) {
        //EXTRAS
        MyFrame frame = new MyFrame("RPG",500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Creamos una batalla
        battle = new FBattle();


        //Creamos, modificamos y añadimos la caja de dialogo
        textBox = createTextBox();

        //Creamos al enemigo
        enemy = new FEnemy("Enemigo",10,200);
        enemy.setSprites("lwjgl3/src/main/resources/RPGBatalla/FightTest/Sprites/");
        //enemy.setBrightness(100);
        enemy.setactualSprite(0); //Sprite actual

        //Creamos al jugador
        player = new FPlayer("jugador",10,100);

        //Obtenemos el mando del jugador
        command = player.getCommand();
        //Y le añadimos botones
        FButton[] buttons = createButtons();

        //Creamos una consola
        command.createConsole();
        //La consola la usaremos para representar el HP de nuestro jugador
        command.setConsoleText("HP: " + player.getHP());
        //Con que tecla se confirmara algun boton
        command.setConfirmKey(KeyEvent.VK_ENTER);

        //Extras
        Timer timer = new Timer(100, null);
        final int[] miniIterador = {0};

        //Creamos una accion para el boton "atacar"
        buttons[0].setActionListener(e -> {
            if (command.state == FCommand.ACTIVATED){
                attack(miniIterador, timer);
            } else if (command.state == FCommand.ONLYCONFIRM){
                takeDamage(miniIterador,timer);
            }
        });
        //Creamos una accion para el boton "curar"
        buttons[1].setActionListener(e ->{
            if (command.state == FCommand.ACTIVATED){
                heal();
            } else if (command.state == FCommand.ONLYCONFIRM){
                takeDamage(miniIterador,timer);
            }
        });

        command.addButton(buttons[0]); //Añadir al mando el boton "atacar"
        command.addButton(buttons[1]); //Añadir al mando el boton "defenderse"

        //Finalmente añadimos a todos

        FBackground background = battle.getFBackground();
        try {
            background.setImage("C:\\Users\\Usuario\\Desktop\\ProyectoRPG\\Nueva carpeta\\RPGBatalla\\RPG_Overworld\\lwjgl3\\src\\main\\resources\\RPGBatalla\\FightTest\\Walls\\FWallTestImage.png");
            background.setImageRepeat(true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //background.setBrightness(3.0f, 100);
        //background.changeColor(Color.red);
        //background.setAlpha(50);
        background.monoColor(Color.black, 80);
        background.scalate(2.0f,2.0f);
        background.pos(0,0);

        //background.pos(1,1);

        //enemy.pos(500,0);
        //enemy.rotate(45);
        //enemy.scalate(1.2f,1.2f);

        battle.add(player); //Añadimos al jugador a la batalla
        battle.add(textBox);
        battle.add(enemy);

        frame.add(battle);

        //EXTRAS
        frame.pack();
        frame.setVisible(true);
    }

    public static FTextBox createTextBox(){
        FTextBox textBox = new FTextBox();
        //Asignamos texto
        textBox.setText("Enemigo encontrado");
        //Decoramos la caja de dialogo
        textBox.setHeight(100);
        textBox.setBackgroundColor(Color.gray);
        textBox.setBorderTickness(5);
        textBox.setBorderColor(Color.black);
        return textBox;
    }

    public static FButton[] createButtons(){
        FButton[] buttons = new FButton[2];
        buttons[0] = new FButton();
        buttons[0].setText("ATACAR");
        buttons[0].setButtonColor(Color.red);
        buttons[0].setTextColor(Color.black);

        buttons[1] = new FButton();
        buttons[1].setText("CURARSE");
        buttons[1].setButtonColor(Color.orange);
        buttons[1].setTextColor(Color.black);
        return buttons;
    }

    public static void attack(final int[] miniIterador, Timer timer){
        command.state = FCommand.DESACTIVATED;
        textBox.setText("HAZ GOLPEADO AL ENEMIGO!!!");
        enemy.setactualSprite(4);
        enemy.setHP(enemy.getHP() - player.getAttackDamage());
        timer.addActionListener(e->{
            miniIterador[0]++;
            switch (miniIterador[0]){
                case 4:
                    enemy.setactualSprite(5);
                    break;
                case 8:
                    enemy.setactualSprite(6);
                    break;
                case 16:
                    enemy.setactualSprite(1);
                    textBox.setText("El enemigo se ha cubierto! [TOCA ENTER]");
                    command.state = FCommand.ONLYCONFIRM;
                    miniIterador[0] = 0;
                    timer.removeActionListener(timer.getActionListeners()[0]);
                    timer.stop();
                    break;
            }
        });
        timer.start();
    }

    public static void takeDamage(final int[] miniIterador, Timer timer){
        textBox.setText("turno del enemigo!!!");
        enemy.setactualSprite(2);
        command.state = FCommand.DESACTIVATED;
        timer.addActionListener(e->{
            miniIterador[0]++;
            switch (miniIterador[0]){
                case 8:
                    enemy.setactualSprite(3);
                    player.setHP(player.getHP() - enemy.getAttackDamage());
                    command.setConsoleText("HP: " + player.getHP());
                    textBox.setText("Haz recibido daño!!!");
                    break;
                case 12:
                    enemy.setactualSprite(0);
                    command.state = FCommand.ACTIVATED;
                    miniIterador[0] = 0;
                    timer.removeActionListener(timer.getActionListeners()[0]);
                    timer.stop();
                    break;
            }
        });
        timer.start();
    }
    public static void heal(){
        command.state = FCommand.ONLYCONFIRM;
        textBox.setText("TE HAZ CURADO!! [TOCA ENTER]");
        enemy.setactualSprite(6);
        player.setHP(player.getHP() + 5);
        command.setConsoleText("HP: " + player.getHP());
    }
}
