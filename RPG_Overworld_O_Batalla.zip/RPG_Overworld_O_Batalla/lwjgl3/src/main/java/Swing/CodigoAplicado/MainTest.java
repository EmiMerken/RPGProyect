package Swing.CodigoAplicado;

import Swing.Fight.Interfaces.Transformable;
import Swing.Fight.Interfaces.VFX;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MainTest{
    public static void main(String[] args) {
        JFrame frame = new JFrame("ventana");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(800,600);

        JPanel panel = new JPanel();
        panel.setBackground(Color.darkGray);

        Image image = null;
        try {
            image = ImageIO.read(new File("C:\\Users\\Usuario\\Desktop\\ProyectoRPG\\Nueva carpeta\\RPGBatalla\\RPG_Overworld\\lwjgl3\\src\\main\\resources\\RPGBatalla\\FightTest\\Sprites\\0_normal.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        JLabel label = new JLabel(new ImageIcon(image));


        panel.add(label);

        frame.add(panel);
        frame.setVisible(true);
    }
}
