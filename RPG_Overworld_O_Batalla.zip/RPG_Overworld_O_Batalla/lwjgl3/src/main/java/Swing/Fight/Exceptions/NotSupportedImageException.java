package Swing.Fight.Exceptions;

public class NotSupportedImageException extends RuntimeException {
    public NotSupportedImageException(String message) {
        super(message);
    }
}
