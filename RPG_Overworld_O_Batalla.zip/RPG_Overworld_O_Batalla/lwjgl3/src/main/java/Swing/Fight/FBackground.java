package Swing.Fight;

import Swing.Fight.Exceptions.NullImageException;
import Swing.Fight.Interfaces.Filterable;
import Swing.Fight.Interfaces.Transformable;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * "FBackground"
 *
 *  Sirve mayormente para modificar de mejor manera las imagenes dentro de un <div>JPanel</div>
 */
public class FBackground extends JPanel implements Filterable, Transformable {

    private BufferedImage image;
    private Color color;
    private boolean isImageRepeated;
    private int opacity;

    public FBackground(){
        setLayout(new BorderLayout());
        opacity = 100;
        setOpaque(true);
        isImageRepeated = false;
    }

    public void setColor(Color color){
        setOpaque(true);
        this.color = color;
        setBackground(color);
    }

    public void removeColor(){
        setOpaque(false);
        this.color = null;
        setBackground(Color.white);
    }

    public Color getColor() {
        return color;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }

    public void setImage(String path) throws IOException {
        this.image = ImageIO.read(new File(path));
    }

    public void removeImage(){
        this.image = null;
    }

    //TODO: USAR INTERFAZ
    public void setImageSize(int width, int height){
        if (width > 0 && height > 0){
            if (this.image != null){

                Image scaled = this.image.getScaledInstance(width, height, Image.SCALE_FAST);
                BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

                Graphics2D g2d = resized.createGraphics();
                g2d.drawImage(scaled, 0, 0, null);
                g2d.dispose();

                this.image = resized;
            } else {
                throw new NullImageException("La imagen de la clase: " + this.getClass() + " es null");
            }
        } else {
            throw new IllegalArgumentException("El tamaño no puede ser negativo: " + width + " " + height);
        }
    }

    //TODO: INTERFAZ
    public void setImagePos(int x, int y){

    }

    //TODO: POSIBLE INTERFAZ
    public void setImageGap(int xGap, int yGap){
        if (xGap > 0 && yGap > 0){
            //TODO: CODIGO
        } else {
            throw new IllegalArgumentException("La brecha entre imagenes no puede ser negativa: " + xGap + " " + yGap);
        }
    }

    public void setImageRepeat(boolean isImageRepeated){
        this.isImageRepeated = isImageRepeated;
    }

    //TODO: INTERFAZ
    public void setOpacity(int opacity){
        if(opacity >= 0 && opacity <= 100){
            if (image!=null){
                this.opacity = opacity;
                BufferedImage newImage = new BufferedImage(this.image.getWidth(),this.image.getHeight(), BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = newImage.createGraphics();
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, this.opacity / 100f));
                g2d.drawImage(this.image, 0, 0, null);
                g2d.dispose();
                this.image = newImage;
                this.repaint();
            } else {
                throw new NullImageException("La imagen de la clase: " + this.getClass() + " es null");
            }
        } else {
            throw new IllegalArgumentException("Ha elegido una opacidad fuera de lo aceptado: " + opacity);
        }
    }

    public BufferedImage getImage() {
        return image;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //VUELVE LA IMAGEN EN UN MOSAICO QUE SE REPITE POR TÓDO EL PANEL SI EL PROGRAMADOR LO DESEA
        if (this.image != null && isImageRepeated){
            Rectangle rect = new Rectangle(0, 0, this.image.getWidth(), this.image.getHeight());
            TexturePaint texturePaint = new TexturePaint(this.image, rect);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setPaint(texturePaint);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    private BufferedImage paintByPixel(BufferedImage newImage, Color color){
        for (int x = 0; x < newImage.getWidth(); x++) {
            for (int y = 0; y < newImage.getHeight(); y++) {
                //Detecta si el pixel en el que esta es completamente transparente o no
                if (((newImage.getRGB(x,y) >> 24) & 0xff) > 0){
                    newImage.setRGB(x,y,color.getRGB());
                }
            }
        }
        return newImage;
    }

    @Override
    public void changeColor(Color color) {
        image = paintByPixel(image, color);
    }

    @Override
    public void monoColor(Color color, int intensity) {
        BufferedImage original = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = original.createGraphics();
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();
        changeColor(color);
        setAlpha(intensity);
        BufferedImage resultado = new BufferedImage(original.getWidth(),original.getHeight(), BufferedImage.TYPE_INT_ARGB);
        g2d =  resultado.createGraphics();
        g2d.drawImage(original, 0, 0, null);
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();
        image = resultado;
    }

    @Override
    public void setBrightness(float contrast, float offset) {
        RescaleOp applyBrightness = new RescaleOp(contrast, offset, null);
        image = applyBrightness.filter(image,null);
    }

    @Override
    public void setAlpha(int opacity) {
        //TODO: TIRAR EXCEPCION
        BufferedImage newImage = new BufferedImage(image.getWidth(),image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = newImage.createGraphics();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity / 100f));
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();
        image = newImage;
    }

    @Override
    public void pos(int x, int y) {
        //TODO: THROW ERROR
    }

    @Override
    public void rotate(float degrees) {
        //TODO: THROW ERROR
    }

    @Override
    public void scalate(float sizeX, float sizeY) {
        int newWidth = (int) (image.getWidth()*sizeX);
        int newHeight = (int) (image.getHeight()*sizeY);

        BufferedImage newImage = new BufferedImage(newWidth,newHeight,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = newImage.createGraphics();
        g2d.scale(sizeX, sizeY);
        g2d.drawImage(image, 0,0,null);
        g2d.dispose();
        image = newImage;
    }


}
