package Swing.Fight;

import Swing.Fight.Interfaces.Filterable;
import Swing.Fight.Interfaces.Transformable;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.util.Arrays;
import java.util.Objects;

/**
 * "FEnemy"
 *
 * Representa a un enemigo con sus respectivos <code>sprites</code> dentro de un juego RPG
 */
public class FEnemy extends FCharacter implements Filterable, Transformable {


    private ImageIcon[] sprites = new ImageIcon[0];
    private int actualSprite = 0;
    private ImageIcon imageIcon;

    private int x;
    private int y;

    public FEnemy(String name, int attackDamage, int hp){
        super(name,attackDamage,hp);
        setHorizontalAlignment(CENTER);
        textCenter();
    }


    public FEnemy(String name, int attackDamage, int hp, ImageIcon[] sprites) {
        super(name,attackDamage,hp);
        this.sprites = sprites;
        setactualSprite(0);
        setHorizontalAlignment(CENTER);
        textCenter();
    }


    public void setSprites(String directoryPath){
        File directory = new File(directoryPath);
        File[] spriteList = Objects.requireNonNull(directory.listFiles());
        if (directory.isDirectory() && directory.exists()) {
            //Transforma los archivos de una carpeta a un stream que se convierte en una lista de ImageIcon's
            sprites = Arrays.stream(spriteList).map(file -> new ImageIcon(file.getAbsolutePath())).toArray(ImageIcon[]::new);
        }
    }

    /**
     * se asigna un sprite al enemigo
     * @param actualSprite indice del arreglo de sprites
     */
    public void setactualSprite(int actualSprite){
        //TODO : EXCEPTION EN CASO DE QUE NO HAY ARREGLO
        this.actualSprite = actualSprite;
        this.imageIcon = sprites[actualSprite];
        setIcon(sprites[actualSprite]);
    }

    /**
     * Permite centrar el texto y que quede por encima del sprite del enemigo
     */
    private void textCenter(){
        setText(name + " HP: " + HP);
        setHorizontalTextPosition(CENTER);
        setVerticalTextPosition(TOP);
    }

    private BufferedImage imageToBufferedImage(Image image){
        BufferedImage newImage = new BufferedImage(image.getWidth(null),image.getWidth(null),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = newImage.createGraphics();
        g2d.drawImage(image,getWidth(),getHeight(),null);
        g2d.dispose();
        return newImage;
    }

    private BufferedImage paintByPixel(BufferedImage newImage, Color color){
        for (int x = 0; x < newImage.getWidth(); x++) {
            for (int y = 0; y < newImage.getHeight(); y++) {
                //Detecta si el pixel en el que esta es completamente transparente o no
                if (((newImage.getRGB(x,y) >> 24) & 0xff) > 0){
                    newImage.setRGB(x,y,color.getRGB());
                }
            }
        }
        return newImage;
    }

    @Override
    public void setHP(int hp) {
        super.setHP(hp);
        super.setText(name + " HP: " + hp);
    }

    @Override
    public void changeColor(Color color) {
        imageIcon = new ImageIcon(paintByPixel(imageToBufferedImage(imageIcon.getImage()), color));
        setIcon(imageIcon);
    }

    @Override
    public void monoColor(Color color, int intensity) {
        BufferedImage original = imageToBufferedImage(imageIcon.getImage());
        changeColor(color);
        setAlpha(intensity);
        BufferedImage resultado = new BufferedImage(original.getWidth(),original.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resultado.createGraphics();
        g2d.drawImage(original, 0,0,null);
        g2d.drawImage(imageIcon.getImage(), 0,0,null);
        g2d.dispose();
        imageIcon = new ImageIcon(resultado);
        setIcon(imageIcon);
    }

    @Override
    public void setBrightness(float contrast, float offset) {
        RescaleOp applyBrightness = new RescaleOp(contrast, offset, null);
        imageIcon = new ImageIcon(applyBrightness.filter(imageToBufferedImage(imageIcon.getImage()),null));
        setIcon(imageIcon);
    }

    @Override
    public void setAlpha(int opacity) {
        //TODO: VER SI TIRA EXCEPTIONS O NO
        Image image = imageIcon.getImage();
        BufferedImage newImage = new BufferedImage(image.getWidth(null),image.getHeight(null), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = newImage.createGraphics();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity / 100f));
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();
        imageIcon = new ImageIcon(newImage);
        setIcon(imageIcon);
    }

    @Override
    public void pos(int x, int y) {
        this.x = x;
        this.y = y;
        setBorder(new EmptyBorder(0,x,y,0));
    }

    @Override
    public void rotate(float degrees) {
        Image originalImage = imageIcon.getImage();
        BufferedImage newImage = new BufferedImage(originalImage.getWidth(null),originalImage.getHeight(null),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d =  newImage.createGraphics();

        //Toma en cuenta el desplazamiento
        double rotationCenterX = originalImage.getWidth(null) / 2.0;
        double rotationCenterY = originalImage.getHeight(null) / 2.0;
        g2d.rotate(Math.toRadians(degrees), rotationCenterX, rotationCenterY);
        g2d.drawImage(originalImage,0,0,null);
        g2d.dispose();
        imageIcon = new ImageIcon(newImage);
        setIcon(imageIcon);
    }

    @Override
    public void scalate(float sizeX, float sizeY) {
        Image originalImage = imageIcon.getImage();

        int newWidth = (int) (originalImage.getWidth(null)*sizeX);
        int newHeight = (int) (originalImage.getHeight(null)*sizeY);

        BufferedImage newImage = new BufferedImage(newWidth,newHeight,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d =  newImage.createGraphics();
        g2d.scale(sizeX, sizeY);
        g2d.drawImage(originalImage, 0,0,null);
        g2d.dispose();
        imageIcon = new ImageIcon(newImage);
        setIcon(imageIcon);
    }
}

