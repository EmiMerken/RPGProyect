package Swing.Fight;

import Swing.Fight.Interfaces.Filterable;
import Swing.Fight.Interfaces.Transformable;

import javax.swing.*;
import java.awt.*;

//Panel que estara por encima de todas las demas
public class FOverlay extends JPanel implements Transformable, Filterable {

    //mando que le permitira al jugador elegir que hara
    private FCommand command;
    private JLabel label = new JLabel();

    public FOverlay(){
        setLayout(new FlowLayout());
        setOpaque(true);
        add(label);
    }

    public void addFCommand(FCommand command){
        this.command = command;
        add(command);
    }

    public void setText(String text){
        label.setText(text);
    }

    public void setImage(String path){
        //TODO: THROW IMAGE ERROR's
        label.setIcon(new ImageIcon(path));
    }

    public void showPanel(Boolean b){
        setVisible(b);
    }

    @Override
    public void changeColor(Color color) {
        setBackground(color);
    }

    @Override
    public void monoColor(Color color, int intensity) {

    }

    @Override
    public void setBrightness(float contrast, float offset) {

    }

    @Override
    public void setAlpha(int opacity) {

    }

    @Override
    public void pos(int x, int y) {

    }

    @Override
    public void rotate(float degrees) {

    }

    @Override
    public void scalate(float sizeX, float sizeY) {

    }
}
