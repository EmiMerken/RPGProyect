package Swing.Sonido;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Objects;

public class Sonido {

    private Clip clip;

    private URL[] soundURL;

    public Sonido() {
    }

    public Sonido(String directoryPath) {
        cargarSonidos(directoryPath);
    }

    public void cargarSonidos(String directoryPath) {
        File directory = new File(directoryPath);
        File[] listaDeSonidos = Objects.requireNonNull(directory.listFiles());
        if (directory.isDirectory() && directory.exists()) {
            soundURL = Arrays.stream(listaDeSonidos).map(file1 -> {
                try {
                    return file1.toURI().toURL();
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }).toArray(URL[]::new);
        }
    }

    public void cargarSonido(int sonido) throws ExcepcionSonido{
        try {
            if (soundURL[sonido] == null) {
                System.err.println("No se puede cargar el sonido " + sonido + ": recurso no encontrado");
            }
            AudioInputStream audio = AudioSystem.getAudioInputStream(soundURL[sonido]);
            clip = AudioSystem.getClip();
            clip.open(audio);
            System.out.println("Sonido: " + sonido + " cargado correctamente");

        } catch (IllegalArgumentException e) {
           throw new ExcepcionSonido(e.getMessage());
        }catch (Exception e){
            throw new ExcepcionSonido("error al cargar sonido: " + e.getMessage());}
    }

    public void play() {
        if (clip != null && !clip.isRunning()) {
            clip.setFramePosition(0);
            clip.start();
        }
    }

    public void stop() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }

    public void loop() {
        if (clip != null) {
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }
}
