package Swing.Sonido;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.IllegalFormatException;
import java.util.Objects;
import java.util.stream.Collectors;

public class Sonido {

    //Los cambios mios (Tomas) estan comentados con un "(TOMAS)"

    private Clip clip;

    // (TOMAS)
    // Quite el "final",
    // "private final URL[] soundURL" -> "private URL[] soundURL"
    private URL[] soundURL;

    // (TOMAS) quite lo que habia dentro
    public Sonido() {
    }

    // (TOMAS) Cree otro constructor para que "cargarSonidos" se pueda hacer de inmediato
    public Sonido(String directoryPath) {
        cargarSonidos(directoryPath);
    }

    // (TOMAS)
    // Converti la logica de lista a programacion funcional
    // (Extra) : Desde mi computador, me funciono esta ruta: lwjgl3\src\main\resources\RPGBatalla\FightTest\Sonido
    // (Extra) : Asegurate de que tus archivos de audios esten identificados como audio en tu IDE
    public void cargarSonidos(String directoryPath) {
        File directory = new File(directoryPath);
        File[] listaDeSonidos = Objects.requireNonNull(directory.listFiles());
        if (directory.isDirectory() && directory.exists()) {
            soundURL = Arrays.stream(listaDeSonidos).map(file1 -> {
                try {
                    return file1.toURI().toURL();
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }).toArray(URL[]::new);
        }
    }

    public void cargarSonido(int sonido) throws ExcepcionSonido{
        try {
            if (soundURL[sonido] == null) {
                System.err.println("No se puede cargar el sonido " + sonido + ": recurso no encontrado");
            }
            AudioInputStream audio = AudioSystem.getAudioInputStream(soundURL[sonido]);
            clip = AudioSystem.getClip();
            clip.open(audio);
            System.out.println("Sonido: " + sonido + " cargado correctamente");

        } catch (IllegalArgumentException e) {
           throw new ExcepcionSonido(e.getMessage());
        }catch (Exception e){
            throw new ExcepcionSonido("error al cargar sonido: " + e.getMessage());}
    }

    public void play() {
        if (clip != null && !clip.isRunning()) {
            clip.setFramePosition(0);
            clip.start();
        }
    }

    public void stop() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }

    public void loop() {
        if (clip != null) {
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }
}
